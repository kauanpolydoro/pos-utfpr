package br.edu.utfpr.praticaagil.veiculo.service;

import java.util.List;

import javax.management.InvalidAttributeValueException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.edu.utfpr.praticaagil.veiculo.model.Veiculo;
import br.edu.utfpr.praticaagil.veiculo.repository.VeiculoRepository;

@Service
public class VeiculoService {
	
	@Autowired
	private VeiculoRepository veiculoRep;
	
	public Veiculo salvar(Veiculo veiculo) throws Exception {
		
		if (veiculo.getPlaca() == null || veiculo.getPlaca().length() < 7) {
			throw new InvalidAttributeValueException();
		}
		
		
		veiculoRep.save(veiculo);
	
		return veiculo;
	}
	
	public List<Veiculo> listar() {		
		return veiculoRep.findAll();
	}

}
