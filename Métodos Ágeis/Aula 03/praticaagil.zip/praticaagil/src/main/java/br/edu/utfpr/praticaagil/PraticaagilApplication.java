package br.edu.utfpr.praticaagil;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PraticaagilApplication {

	public static void main(String[] args) {
		SpringApplication.run(PraticaagilApplication.class, args);
	}

}
