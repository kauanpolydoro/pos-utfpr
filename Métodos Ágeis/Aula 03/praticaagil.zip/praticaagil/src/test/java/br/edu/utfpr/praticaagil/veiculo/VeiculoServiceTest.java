package br.edu.utfpr.praticaagil.veiculo;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import br.edu.utfpr.praticaagil.veiculo.model.Veiculo;
import br.edu.utfpr.praticaagil.veiculo.service.VeiculoService;

@SpringBootTest
public class VeiculoServiceTest {
	
	@Autowired
	private VeiculoService veiculoService;

	@Test
	public void deveSalvarUmVeiculo() throws Exception {
		Veiculo veiculo = new Veiculo();
		veiculo.setMarca("VW");
		veiculo.setModelo("GOLF GTI");
		veiculo.setPlaca("AAA0001");
		
		veiculoService.salvar(veiculo);
		
		assertEquals(veiculo.getId(), 1);
	}
	
	@Test
	public void naoDeveSalvarQuandoOVeiculoEInvalido() {		
		Veiculo veiculo = new Veiculo();
		veiculo.setMarca("VW");
		veiculo.setModelo("GOLF GTI");
		veiculo.setPlaca("AAA000");

		try {
			veiculoService.salvar(veiculo);
		} catch (Exception e) {			
		}
		
		assertEquals(veiculo.getId(), null);
	}

}
