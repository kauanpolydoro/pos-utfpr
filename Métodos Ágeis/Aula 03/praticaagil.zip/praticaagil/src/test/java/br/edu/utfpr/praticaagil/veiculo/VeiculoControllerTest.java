package br.edu.utfpr.praticaagil.veiculo;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import io.restassured.RestAssured;

public class VeiculoControllerTest {
	
	@Test
	public void deveSalvarUmVeiculo() throws Exception {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		RestAssured.given().
			headers(headers).
			body("{\"marca\":\"Fiat\", \"modelo\":\"Fiat 147\", \"placa\":\"AAA0001\"} ").when().
			post("http://localhost:8080/veiculo").then().
			statusCode(200);
	}
	
	@Test
	public void naoDeveSalvarQuandoOVeiculoEInvalido() {		
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		RestAssured.given().
			headers(headers).
			body("{\"marca\":\"Fiat\", \"modelo\":\"Fiat 147\", \"placa\":\"AAA000\"} ").when().
			post("http://localhost:8080/veiculo").then().
			statusCode(500);
	}

}
